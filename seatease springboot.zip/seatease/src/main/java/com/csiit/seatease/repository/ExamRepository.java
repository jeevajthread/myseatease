package com.csiit.seatease.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.csiit.seatease.entity.Exam;

public interface ExamRepository extends JpaRepository<Exam, Long>{

}
