package com.csiit.seatease.service;

import com.csiit.seatease.dto.AuthenticationRequest;
import com.csiit.seatease.entity.Admin;

public interface AdminService {
	
	public String addNewAdmin(Admin admin);
	//public Admin saveAdmin(Admin admin);
	//public Admin authenticateAdmin(AuthenticationRequest admin) ;
	
		
	

}
